﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppDesk_Poetry
{
    /// <summary>
    /// Lógica de interacción para FavoritesView.xaml
    /// </summary>
    public partial class FavoritesView : UserControl
    {
        public FavoritesView()
        {
            InitializeComponent();
            LoadFavorites();
        }

        // Método para buscar los poemas marcados como Favorito.
        private void LoadFavorites()
        {
            // Obtiene la lista de poemas y filtra los que son favoritos.
            var mainWindow = (MainWindow)Application.Current.MainWindow;
            var favoritePoems = mainWindow.Poems.Where(poem => poem.IsFavorite).ToList();

            // Aparecen en el DataGrid de la sección de Favoritos.
            FavoritesDataGrid.ItemsSource = favoritePoems;
        }
    }
}
