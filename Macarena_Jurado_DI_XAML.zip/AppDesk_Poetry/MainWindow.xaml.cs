﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppDesk_Poetry;
/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{

    // Almacena los poemas.
    public ObservableCollection<Poem> Poems { get; } = new ObservableCollection<Poem>();

    public MainWindow()
    {
        InitializeComponent();
    }


    private void OnMenuSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!(e.Source is ListView listView)) return;

        UserControl newView = null;

        // Indica qué ítem es seleccionado.
        switch (((ListViewItem)listView.SelectedItem).Name)
        {
            // Muestra la vista de la página de inicio:
            case "ItemHome":
                HomeContent.Visibility = Visibility.Visible;
                HomeTilesUniformGrid.Visibility = Visibility.Visible; 
                MainContent.Visibility = Visibility.Collapsed;
                break;

            // Muestra la vista de la página de búsqueda:
            case "ItemSearch":
                newView = new SearchView();
                break;

            // Muestra la vista de la página de favoritos:
            case "ItemFavorites":
                newView = new FavoritesView();
                break;

            // Muestra la vista de la página de agregar poema:
            case "ItemAddPoem":
                newView = new AddPoemView();
                ((AddPoemView)newView).MainWindowReference = this;
                break;

            // Muestra la vista de la página de perfil:
            case "ItemProfile":
                newView = new ProfileView();
                break;

            // Muestra la vista de la página de ayuda:
            case "ItemHelp":
                newView = new HelpView();
                break;
        }

        // El UserControl es el contenido del ContentControl.
        if (newView != null)
        {
            HomeContent.Visibility = Visibility.Collapsed;
            HomeTilesUniformGrid.Visibility = Visibility.Collapsed; // Oculta el UniformGrid cuando se selecciona otra vista.
            MainContent.Visibility = Visibility.Visible;
            MainContent.Content = newView;
        }
    }



}