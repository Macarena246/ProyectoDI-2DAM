﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppDesk_Poetry;
/// <summary>
/// Lógica de interacción para AddPoemView.xaml
/// </summary>
public partial class AddPoemView : UserControl
{

    public MainWindow MainWindowReference { get; set; }

    public AddPoemView()
    {
        InitializeComponent();
    }

    // Manejador de eventos para guardar el poema.
    private void SavePoem_Click(object sender, RoutedEventArgs e)
    {
        // Validación de los datos que ingresa el usuario.
        if (string.IsNullOrWhiteSpace(TitleTextBox.Text))
        {
            MessageBox.Show("Por favor, ingresa un título para el poema.");
            return;
        }

        if (string.IsNullOrWhiteSpace(AuthorTextBox.Text))
        {
            MessageBox.Show("Por favor, ingresa el nombre del autor.");
            return;
        }

        if (!DateDatePicker.SelectedDate.HasValue)
        {
            MessageBox.Show("Por favor, selecciona una fecha.");
            return;
        }

        if (string.IsNullOrWhiteSpace(PoemContentTextBox.Text))
        {
            MessageBox.Show("Debes añadir el contenido del poema.");
            return;
        }

        // Se guarda el poema con los datos recogidos.
        var newPoem = new Poem
        {
            Title = TitleTextBox.Text,
            Author = AuthorTextBox.Text,
            Date = DateDatePicker.SelectedDate.Value,
            Content = PoemContentTextBox.Text

        };

        MainWindowReference.Poems.Add(newPoem);

        // Deja vacíos los campos después de guardar los datos.
        TitleTextBox.Text = string.Empty;
        AuthorTextBox.Text = string.Empty;
        DateDatePicker.SelectedDate = null;
        PoemContentTextBox.Text = string.Empty;

        // Muestra un mensaje de feedback para el usuario.
        MessageBox.Show("El poema se ha guardado correctamente.");
    }

    // Método para limpiar el texto de un TextBox a la hora de escribir.
    private void ClearTextBox(object sender, RoutedEventArgs e)
    {
        TextBox textBox = sender as TextBox;

        // Texto que hace de marcador en el TextBox.
        if (textBox != null)
        {
            if (textBox.Text == "Comienza a escribir aquí...") // Limpia el TextBox.
            {
                textBox.Text = string.Empty;
            }
        }
    }
}
