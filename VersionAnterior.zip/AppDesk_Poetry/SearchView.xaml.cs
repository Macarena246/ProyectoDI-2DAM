﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppDesk_Poetry
{
    /// <summary>
    /// Lógica de interacción para SearchView.xaml
    /// </summary>
    public partial class SearchView : UserControl
    {
        public ObservableCollection<Poem> Poems{ get; set; }
        public SearchView()
        {
            InitializeComponent();

            // Accede a la lista de poemas creada en MainWindow.
            Poems = ((MainWindow)Application.Current.MainWindow).Poems;
        }

        // Manejador de eventos para buscar el poema.
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            string searchTerm = SearchBox.Text.ToLowerInvariant();
            var filteredPoems = Poems.Where(poem =>
                poem.Title.ToLowerInvariant().Contains(searchTerm) ||
                poem.Author.ToLowerInvariant().Contains(searchTerm) ||
                poem.Content.ToLowerInvariant().Contains(searchTerm) ||
                poem.Date.ToString("d").Contains(searchTerm)).ToList();

            ResultsDataGrid.ItemsSource = filteredPoems;

            if (!filteredPoems.Any())
            {
                MessageBox.Show("No se encontraron resultados.");
            }
        }
    }
}
