﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppDesk_Poetry;
/// <summary>
/// Lógica de interacción para HelpView.xaml
/// </summary>
public partial class HelpView : UserControl
{
    public HelpView()
    {
        InitializeComponent();
    }

    // Manejador de evento para mostrar el formulario de ayuda.
    private void Hyperlink_Click(object sender, RoutedEventArgs e)
    {
        // Muestra el StackPanel con los campos de formulario.
        ContactFormPanel.Visibility = Visibility.Visible;
    }

    // Método para mostrar el formulario.
    private void ShowContactForm()
    {
        // StackPanel que contiene el formulario.
        ContactFormPanel.Visibility = Visibility.Visible;
    }

    // Manejador de evento al clicar en Enviar.
    private void SendButton_Click(object sender, RoutedEventArgs e)
    {
        // Valida el nombre
        if (string.IsNullOrWhiteSpace(NameTextBox.Text))
        {
            MessageBox.Show("Por favor, ingresa tu nombre.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        // Valida el correo electrónico
        if (!IsValidEmail(EmailTextBox.Text))
        {
            MessageBox.Show("Por favor, ingresa un correo electrónico válido.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        // Valida el asunto
        if (string.IsNullOrWhiteSpace(SubjectTextBox.Text))
        {
            MessageBox.Show("Por favor, ingresa un asunto.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        // Valida el mensaje
        if (string.IsNullOrWhiteSpace(MessageTextBox.Text))
        {
            MessageBox.Show("Por favor, ingresa tu mensaje.", "Validación", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        // Simula el envío del mensaje.
        MessageBox.Show("Tu mensaje ha sido enviado correctamente.", "Mensaje Enviado", MessageBoxButton.OK, MessageBoxImage.Information);

        // Ocultar el formulario.
        ContactFormPanel.Visibility = Visibility.Collapsed;

        // Limpia los campos del formulario.
        NameTextBox.Clear();
        EmailTextBox.Clear();
        SubjectTextBox.Clear();
        MessageTextBox.Clear();
    }

    // Método booleano que valida el email con el formato correcto.
    private bool IsValidEmail(string email)
    {
        try
        {
            var addr = new System.Net.Mail.MailAddress(email);
            return addr.Address == email;
        }
        catch
        {
            return false;
        }
    }


    // Manejador de evento que marca lo que escribe el usuario.
    private void TextBox_GotFocus(object sender, RoutedEventArgs e)
    {
        TextBox textBox = sender as TextBox;
        if (textBox != null)
        {
            if ((textBox.Name == "NameTextBox" && textBox.Text == "Nombre completo") ||
                (textBox.Name == "EmailTextBox" && textBox.Text == "Correo electrónico") ||
                (textBox.Name == "SubjectTextBox" && textBox.Text == "Asunto") ||
                (textBox.Name == "MessageTextBox" && textBox.Text == "Mensaje"))
            {
                textBox.Text = "";
                textBox.Foreground = Brushes.Black;
            }
        }
    }

    // Manejador de evento que deja un texto provisional antes de que escriba el usuario.
    private void TextBox_LostFocus(object sender, RoutedEventArgs e)
    {
        TextBox textBox = sender as TextBox;
        if (textBox != null)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                switch (textBox.Name)
                {
                    case "NameTextBox":
                        textBox.Text = "Nombre completo";
                        break;
                    case "EmailTextBox":
                        textBox.Text = "Correo electrónico";
                        break;
                    case "SubjectTextBox":
                        textBox.Text = "Asunto";
                        break;
                    case "MessageTextBox":
                        textBox.Text = "Mensaje";
                        break;
                }
                textBox.Foreground = Brushes.Gray;
            }
        }
    }

    // Manejador de evento para cancelar el envío.
    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        // Oculta el StackPanel del formulario de contacto.
        ContactFormPanel.Visibility = Visibility.Collapsed;

        // Limpia los campos.
        NameTextBox.Clear();
        EmailTextBox.Clear();
        SubjectTextBox.Clear();
        MessageTextBox.Clear();
    }

}
