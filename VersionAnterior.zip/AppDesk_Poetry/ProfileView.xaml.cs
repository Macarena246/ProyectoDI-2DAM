﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AppDesk_Poetry
{
    /// <summary>
    /// Lógica de interacción para ProfileView.xaml
    /// </summary>
    public partial class ProfileView : UserControl
    {
        public ProfileView()
        {
            InitializeComponent();

            // Relación del DataGrid con la colección de poemas.
            PoemsDataGrid.ItemsSource = ((MainWindow)Application.Current.MainWindow).Poems;
        }

        // Manejador de eventos para editar los poemas.
        private void EditPoem_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var poem = button.DataContext as Poem;

            // Se registran los datos actualizados del poema.
            EditTitle.Text = poem.Title;
            EditAuthor.Text = poem.Author;
            EditDate.SelectedDate = poem.Date;
            EditContent.Text = poem.Content;

            // Guarda referencia del poema que se está editando.
            EditPanel.Tag = poem;

            // Muestra el panel de edición.
            EditPanel.Visibility = Visibility.Visible;
        }

        // Manejador de eventos para guardar el poema editado.
        private void SaveEdit_Click(object sender, RoutedEventArgs e)
        {
            var poem = EditPanel.Tag as Poem;

            // Actualiza los datos del poema.
            poem.Title = EditTitle.Text;
            poem.Author = EditAuthor.Text;
            poem.Date = EditDate.SelectedDate.Value;
            poem.Content = EditContent.Text;

            // Oculta el panel de edición y actualiza el Datagrid.
            EditPanel.Visibility = Visibility.Collapsed;
            PoemsDataGrid.Items.Refresh();
        }

        // Manejador de eventos para cancelar la edición de un poema.
        private void CancelEdit_Click(object sender, RoutedEventArgs e)
        {
            // Oculta el panel de edición sin guardar los cambios.
            EditPanel.Visibility = Visibility.Collapsed;
        }

        // Manejador de eventos para eliminar los poemas.
        private void DeletePoem_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var poem = button.DataContext as Poem;

            // Confirmar eliminación.
            var result = MessageBox.Show("¿Estás seguro de que deseas eliminar este poema?", "Eliminar Poema", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            
            if (result == MessageBoxResult.Yes)
            {
                // Elimina el poema.
                ((MainWindow)Application.Current.MainWindow).Poems.Remove(poem);

                // Actualización del Datagrid.
                PoemsDataGrid.Items.Refresh();
            }
        }

        // Manejador de eventos para marcar como favorito un poema.
        private void ToggleFavorite_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            var poem = button.DataContext as Poem;

            // Muestra un mensaje según si se ha agregado o eliminado de favoritos.
            poem.IsFavorite = !poem.IsFavorite;
            if (poem.IsFavorite)
            {
                MessageBox.Show("Agregado a Favoritos", "Favoritos", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Eliminado de Favoritos", "Favoritos", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            // Actualiza la interfaz de usuario refrescando el DataGrid.
            PoemsDataGrid.Items.Refresh();
        }
    }
}
